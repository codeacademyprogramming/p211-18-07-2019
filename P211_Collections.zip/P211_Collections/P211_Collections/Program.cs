﻿using System;
using System.Collections.Generic;

namespace P211_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Stack
            //Stack bakuBus = new Stack();
            //bakuBus.Push("Samir");
            //bakuBus.Push("Ramiz");
            //bakuBus.Push("Nurlan");

            //Console.WriteLine(bakuBus.Peek());
            //Console.WriteLine(bakuBus.Pop());
            //Console.WriteLine(bakuBus.Peek());
            #endregion

            #region Queue

            //Queue cinemaQueue = new Queue();
            //cinemaQueue.Enqueue("Samir");
            //cinemaQueue.Enqueue("Ramiz");
            //cinemaQueue.Enqueue("Nurlan");
            //cinemaQueue.Enqueue("Amelie");

            //Console.WriteLine(cinemaQueue.Dequeue());
            //Console.WriteLine(cinemaQueue.Peek());
            //Console.WriteLine(cinemaQueue.Dequeue());

            //cinemaQueue.Enqueue("Emil");

            //Console.WriteLine(cinemaQueue.Peek());


            #endregion

            #region ArrayList

            //ArrayList numbers = new ArrayList();
            //numbers.Add(10);
            //numbers.Add(20);
            //numbers.Add(37);
            //numbers.Add(31);
            //numbers.Add(34);
            //numbers.Add(true);
            //numbers.Add("Samir");

            //int sum = 0;
            //foreach (object item in numbers)
            //{
            //    if(item is int)
            //    {
            //        sum += (int)item;
            //    }
            //}

            //Console.WriteLine(sum);

            #region boxing unboxing
            //object o = 15; // boxing

            ////int a = (int)o; //unboxing

            //int? a = o as int?;

            //Console.WriteLine(a);
            #endregion



            #endregion

            #region Virtual & Override (polymorphism)

            //Kachok Aqil = new Kachok();
            //Aqil.Talk();

            //Human human = Aqil;
            //human.Talk();

            #endregion

            #region List
            //int[] oddNumbers = new[] { 11, 15, 25, 79, 81 };
            //List<int> evenNumbers = new List<int> { 12, 8, 6, 4, 246 };

            //List<int> numbers = new List<int>();
            //numbers.Add(14);
            //numbers.AddRange(oddNumbers);
            //numbers.AddRange(evenNumbers);

            //List<int> middleNumbers = numbers.GetRange(numbers.Count / 2, 5);
            //middleNumbers.InsertRange(3, new[] { 10, 2 });

            //foreach (var n in middleNumbers)
            //{
            //    Console.WriteLine(n);
            //}
            #endregion

            #region Dictinoary
            //Dictionary<string, Kachok> p211 = new Dictionary<string, Kachok>();

            //p211["instructor"] = new Kachok { Name = "Samir" };
            //p211["sleepy"] = new Kachok { Name = "Amelie" };
            //p211["horse"] = new Kachok { Name = "Nihat" };
            //p211["mentor"] = new Kachok { Name = "Nihat" };
            //p211["singer"] = new Kachok { Name = "Gul" };

            //p211.Add("miz", new Kachok { Name = "Ramiz" });
            #endregion

            #region HashSet
            //HashSet<int> numbers = new HashSet<int>();
            //numbers.Add(15);
            //numbers.Add(25);
            //numbers.Add(43);
            //numbers.Add(15);
            //numbers.Add(43);
            //numbers.Add(10);

            //Console.WriteLine(numbers.Count);

            //int sum = 0;
            //foreach (var item in numbers)
            //{
            //    sum += item;
            //}

            //Console.WriteLine(sum);
            #endregion
        }
    }

    abstract class Human
    {
        public virtual void Talk()
        {
            Console.WriteLine("I am talking as a human");
        }

        public abstract void Run();

    }

    class Kachok : Human
    {
        public string Name { get; set; }
        public override void Talk()
        {
            Console.WriteLine("I am talking as a Kachok");   
        }

        public override void Run()
        {
            Console.WriteLine("I am running fast");
        }
    }
}
